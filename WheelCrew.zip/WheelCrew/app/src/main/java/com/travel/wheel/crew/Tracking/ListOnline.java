package com.travel.wheel.crew.Tracking;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.travel.wheel.crew.Authentication.User;
import com.travel.wheel.crew.R;

public class ListOnline extends AppCompatActivity {

    DatabaseReference onlineRef,currentUserRef,counterRef;

   // FirebaseRecyclerAdapter<User1, ListOnlineViewHolder> adapter;



    RecyclerView listOnline;
    RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_online);

    }
}
