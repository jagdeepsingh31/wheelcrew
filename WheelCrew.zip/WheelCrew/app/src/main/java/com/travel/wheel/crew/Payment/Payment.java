package com.travel.wheel.crew.Payment;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.travel.wheel.crew.Authentication.Signin;
import com.travel.wheel.crew.ManageCars.ManageCar;
import com.travel.wheel.crew.R;
import com.travel.wheel.crew.WelcomeUser.WelcomeUser;

public class Payment extends AppCompatActivity {
Button paytm,mastercard,visa,paypal,googlepay,bhim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        paytm=(Button)findViewById(R.id.paytm);
        mastercard=(Button)findViewById(R.id.creditcard);
        visa=(Button)findViewById(R.id.visa);
        paypal=(Button)findViewById(R.id.paypal);
        googlepay=(Button)findViewById(R.id.google);
        bhim=(Button)findViewById(R.id.bhim);

        paytm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Payment.this, WelcomeUser.class));
                Toast.makeText(Payment.this,"Booking Done\nPayment Made Using Paytm",Toast.LENGTH_LONG).show();
            }
        });

        mastercard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Payment.this, WelcomeUser.class));
                Toast.makeText(Payment.this,"Booking Done\nPayment Made Using Mastercard",Toast.LENGTH_LONG).show();
            }
        });

    }
}
