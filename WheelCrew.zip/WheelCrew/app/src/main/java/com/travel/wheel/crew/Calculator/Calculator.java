package com.travel.wheel.crew.Calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.travel.wheel.crew.ManageCars.ManageCar;
import com.travel.wheel.crew.R;

public class Calculator extends AppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener{
TextView car_charges,service_charge,car_mileage,subtotal_fuel_cost,
        subtotal_car_charges,subtotal_service_charge,total_trip_cost,per_km_cost;

ScrollView cal_scroll;
EditText no_of_days,fuel_rate,total_kms;
Spinner calcategory,calfuel;
Button calculate;
Button fuel_rate_add,fuel_rate_sub;
String carcategory;
String fueltype;


int noofdays;
float cartotalrent;
float carcharge;
float servicecharge;
float mileage;
float fuelrate;
float totalkms;
float totalcost;
float perkmcost;
float subfuelcost;
float subcarcharges;
float subservicecharge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        cal_scroll=(ScrollView)findViewById(R.id.cal_scroll);
        calcategory=(Spinner) findViewById(R.id.cal_category);
        calfuel=(Spinner)findViewById(R.id.cal_fuel);
        no_of_days=(EditText)findViewById(R.id.no_of_days);
        car_charges=(TextView)findViewById(R.id.car_charges);
        service_charge=(TextView)findViewById(R.id.service_charge);
        car_mileage=(TextView)findViewById(R.id.car_mileage);
        fuel_rate=(EditText) findViewById(R.id.fuel_rate);
        total_kms=(EditText) findViewById(R.id.total_kms);
        subtotal_fuel_cost=(TextView)findViewById(R.id.subtotal_fuel_cost);
        subtotal_car_charges=(TextView)findViewById(R.id.subtotal_car_charges);
        subtotal_service_charge=(TextView)findViewById(R.id.subtotal_service_charge);
        total_trip_cost=(TextView)findViewById(R.id.total_trip_cost);
        per_km_cost=(TextView)findViewById(R.id.per_km_cost);
        calculate=(Button)findViewById(R.id.calculate_btn);
        fuel_rate_add=(Button)findViewById(R.id.fuel_rate_add);
        fuel_rate_sub=(Button)findViewById(R.id.fuel_rate_sub);

        calcategory.setOnItemSelectedListener(this);
        calfuel.setOnItemSelectedListener(this);

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                totalkms=Float.parseFloat(total_kms.getText().toString());
                mileage=Float.parseFloat(car_mileage.getText().toString());
                fuelrate=Float.parseFloat(fuel_rate.getText().toString());

                subfuelcost=(totalkms/mileage)*fuelrate;
                subtotal_fuel_cost.setText(String.format("%.2f",subfuelcost));

                noofdays=Integer.parseInt(no_of_days.getText().toString());
                subcarcharges=Float.parseFloat(car_charges.getText().toString());

                cartotalrent=subcarcharges*noofdays;
                subtotal_car_charges.setText(String.format("%.2f",cartotalrent));

                subservicecharge=Float.parseFloat(service_charge.getText().toString());
                subtotal_service_charge.setText(String.format("%.2f",subservicecharge));

                totalcost=subfuelcost+cartotalrent+subservicecharge;
                total_trip_cost.setText(String.format("%.2f",totalcost));

                perkmcost=totalcost/totalkms;
                per_km_cost.setText(String.format("%.2f",perkmcost));

                cal_scroll.fullScroll(ScrollView.FOCUS_DOWN);

            }
        });

        fuel_rate_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fuelrate=Float.parseFloat(fuel_rate.getText().toString());
                fuelrate= (float) (fuelrate+0.01);
                fuel_rate.setText(String.format("%.2f",fuelrate));

            }
        });

        fuel_rate_sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fuelrate=Float.parseFloat(fuel_rate.getText().toString());
                fuelrate= (float) (fuelrate-0.01);
                fuel_rate.setText(String.format("%.2f",fuelrate));
            }
        });

    }




    @Override
    public void onClick(View v) {

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

        Spinner spinner = (Spinner)adapterView;
        switch (spinner.getId()){
            case R.id.cal_category:pricing(i);break;
            case R.id.cal_fuel:FuelType(i);break;
        }

    }

    private void FuelType(int i) {

        if (i==0)
        {
            fuelrate= (float) 0.0;
        }
        else if (i==1)
        {
            fuelrate= (float) 82.38;
        }
        else if (i==2)
        {
            fuelrate= (float) 75.58;
        }
        else if (i==3)
        {
            fuelrate= (float) 45.61;
        }
        fuel_rate.setText(""+fuelrate);
    }

    private void pricing(int i) {
        if(i==0)
        {
            carcharge=0;
            servicecharge=0;
            mileage=0;
        }
        else if(i==1)
        {
            carcharge=1500;
            servicecharge=100;
            mileage=20;
        }
        else if (i==2)
        {
            carcharge=3500;
            servicecharge=100;
            mileage=15;
        }
        else if (i==3)
        {
            carcharge=5000;
            servicecharge=200;
            mileage=12;
        }
        else if (i==4)
        {
            carcharge=7500;
            servicecharge=200;
            mileage=10;
        }
        else if (i==5)
        {
            carcharge=10500;
            servicecharge=500;
            mileage=12;
        }
        else if (i==6)
        {
            carcharge=15000;
            servicecharge=500;
            mileage=8;
        }

        car_charges.setText(""+carcharge);
        service_charge.setText(""+servicecharge);
        car_mileage.setText(""+mileage);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}