package com.travel.wheel.crew.Calculator;

public class cal {
    String carcategory;
    String fueltype;

    float carcharge;
    float servicecharge;
    float mileage;
    float fuelrate;
    float totalkms;
    float totalcost;
    float perkmcost;
    float subfuelcost;
    float subcarcharges;
    float subservicecharge;

    cal(){

    }

    public cal(String carcategory,String fueltype,float carcharge,float servicecharge,float mileage,float fuelrate,float totalkms,
               float totalcost,float perkmcost,float subfuelcost,float subcarcharges,float subservicecharge)
    {
        this.carcategory= carcategory;
        this.fueltype=fueltype;
        this.carcharge=carcharge;
        this.servicecharge=servicecharge;
        this.mileage=mileage;
        this.fuelrate=fuelrate;
        this.totalkms=totalkms;
        this.totalcost=totalcost;
        this.perkmcost=perkmcost;
        this.subfuelcost=subfuelcost;
        this.subcarcharges=subcarcharges;
        this.subservicecharge=subservicecharge;
    }

    public String getCarcategory() {
        return carcategory;
    }

    public void setCarcategory(String carcategory) {
        this.carcategory = carcategory;
    }

    public String getFueltype() {
        return fueltype;
    }

    public void setFueltype(String fueltype) {
        this.fueltype = fueltype;
    }

    public float getCarcharge() {
        return carcharge;
    }

    public void setCarcharge(float carcharge) {
        this.carcharge = carcharge;
    }

    public float getServicecharge() {
        return servicecharge;
    }

    public void setServicecharge(float servicecharge) {
        this.servicecharge = servicecharge;
    }

    public float getMileage() {
        return mileage;
    }

    public void setMileage(float mileage) {
        this.mileage = mileage;
    }

    public float getFuelrate() {
        return fuelrate;
    }

    public void setFuelrate(float fuelrate) {
        this.fuelrate = fuelrate;
    }

    public float getTotalkms() {
        return totalkms;
    }

    public void setTotalkms(float totalkms) {
        this.totalkms = totalkms;
    }

    public float getTotalcost() {
        return totalcost;
    }

    public void setTotalcost(float totalcost) {
        this.totalcost = totalcost;
    }

    public float getPerkmcost() {
        return perkmcost;
    }

    public void setPerkmcost(float perkmcost) {
        this.perkmcost = perkmcost;
    }

    public float getSubfuelcost() {
        return subfuelcost;
    }

    public void setSubfuelcost(float subfuelcost) {
        this.subfuelcost = subfuelcost;
    }

    public float getSubcarcharges() {
        return subcarcharges;
    }

    public void setSubcarcharges(float subcarcharges) {
        this.subcarcharges = subcarcharges;
    }

    public float getSubservicecharge() {
        return subservicecharge;
    }

    public void setSubservicecharge(float subservicecharge) {
        this.subservicecharge = subservicecharge;
    }
}
