package com.travel.wheel.crew.Tracking;

public class User1 {
    private String email,status;

    public User1(String email, String status) {
        this.email = email;
        this.status = status;
    }

    public User1() {

    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
